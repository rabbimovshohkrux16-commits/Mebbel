MEBSHOX — Netlify app / Netlify ilova / Приложение для Netlify
=====================================================================

RU
1. Разархивируйте ZIP в папку.
2. Откройте https://app.netlify.com/drop
3. Перетащите ПАПКУ (с файлами index.html и app.js) в окно браузера.
4. Netlify выдаст ссылку вида https://имя.netlify.app — это ваше приложение.
index.html  — полное приложение: конструктор + анкета (переключатель языка вверху)
anketa.html — только анкета клиента (ставьте эту ссылку в профиль)
app.js      — код приложения (не удаляйте)
Заявки из анкеты приходят в Telegram-бот @Mebzakaz_bot. Владелец должен один раз нажать /start в боте.

UZ
1. ZIP ni papkaga oching.
2. https://app.netlify.com/drop ni oching.
3. PAPKANI (index.html va app.js bilan) brauzer oynasiga torting.
4. Netlify https://nom.netlify.app ko'rinishidagi havola beradi — bu sizning ilovangiz.
Anketa arizalari @Mebzakaz_bot Telegram botiga keladi. Egasi botda bir marta /start bosishi kerak.

EN
1. Unzip the archive into a folder.
2. Open https://app.netlify.com/drop
3. Drag the FOLDER (with index.html and app.js) into the browser window.
4. Netlify gives you a link like https://name.netlify.app — that is your app.
Client form orders are sent to the Telegram bot @Mebzakaz_bot. The owner must press /start in the bot once.


СКАЧАТЬ ДЛЯ ЦЕХА
=================
В правом нижнем углу кнопки:
- Скачать TXT для цеха
- Скачать HTML / PDF (откроется печать → «Сохранить как PDF»)
- Копировать список
Сначала откройте вкладку «Детали / раскрой» (Cutlist).
