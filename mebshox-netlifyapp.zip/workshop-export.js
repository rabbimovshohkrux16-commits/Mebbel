(function () {
  "use strict";

  var LABELS = {
    ru: {
      txt: "Скачать TXT для цеха",
      html: "Скачать HTML / PDF",
      copy: "Копировать список",
      copied: "Скопировано ✓",
      title: "MEBSHOX — раскрой для цеха",
      bar: "Скачать для цеха",
    },
    uz: {
      txt: "Sex uchun TXT yuklab olish",
      html: "HTML / PDF yuklab olish",
      copy: "Ro'yxatni nusxalash",
      copied: "Nusxalandi ✓",
      title: "MEBSHOX — sex uchun kesish",
      bar: "Sex uchun yuklab olish",
    },
    en: {
      txt: "Download TXT for workshop",
      html: "Download HTML / PDF",
      copy: "Copy list",
      copied: "Copied ✓",
      title: "MEBSHOX — workshop cutting",
      bar: "Download for workshop",
    },
  };

  function lang() {
    var t = (document.body.innerText || "").slice(0, 400);
    if (/O'zbek|Oʻzbek|UZ\b/.test(t) && document.querySelector("button")) {
      var active = Array.prototype.find.call(document.querySelectorAll("button"), function (b) {
        return /^(UZ|O'zbek|RU|EN)$/i.test(b.textContent.trim()) && b.className.indexOf("amber") >= 0;
      });
      if (active) {
        var v = active.textContent.trim().toUpperCase();
        if (v === "UZ") return "uz";
        if (v === "EN") return "en";
      }
    }
    var u = (location.hash + location.search + document.documentElement.lang).toLowerCase();
    if (u.indexOf("uz") >= 0) return "uz";
    if (u.indexOf("en") >= 0) return "en";
    return "ru";
  }

  function L() {
    return LABELS[lang()] || LABELS.ru;
  }

  function findPartsTable() {
    var tables = document.querySelectorAll("table");
    for (var i = 0; i < tables.length; i++) {
      var th = tables[i].querySelector("th");
      if (!th) continue;
      var head = tables[i].innerText.slice(0, 200);
      if (/мм|mm|Кол|Qty|Матер|Material|Кром|Edge|детал|Part|Length|Ширин/i.test(head)) {
        return tables[i];
      }
    }
    return null;
  }

  function tableToText(table) {
    var lines = [];
    var titleEl = table.closest("div") && table.closest("div").querySelector("h3");
    lines.push(L().title);
    lines.push(new Date().toLocaleString());
    lines.push("================================");
    if (titleEl) lines.push(titleEl.innerText.trim());
    lines.push("");
    var rows = table.querySelectorAll("tr");
    for (var i = 0; i < rows.length; i++) {
      var cells = rows[i].querySelectorAll("th,td");
      var cols = [];
      for (var j = 0; j < cells.length; j++) cols.push(cells[j].innerText.trim().replace(/\s+/g, " "));
      lines.push(cols.join(" | "));
    }
    // cutting maps captions
    var maps = document.querySelectorAll("h3, h4, p");
    for (var k = 0; k < maps.length; k++) {
      var tx = maps[k].innerText.trim();
      if (/Карта раскроя|Cutting map|kesish xaritasi|Лист №|Sheet #|Varaq/i.test(tx)) {
        lines.push("");
        lines.push(tx);
      }
    }
    return lines.join("\n");
  }

  function download(filename, content, mime) {
    var blob = new Blob([content], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 2000);
  }

  function downloadTxt() {
    var table = findPartsTable();
    if (!table) {
      alert("Откройте вкладку «Детали / раскрой» (Cutlist), затем нажмите снова.");
      return;
    }
    var stamp = new Date().toISOString().slice(0, 10);
    download("mebshox-raskroy-" + stamp + ".txt", tableToText(table), "text/plain;charset=utf-8");
  }

  function downloadHtml() {
    var table = findPartsTable();
    if (!table) {
      alert("Откройте вкладку «Детали / раскрой» (Cutlist), затем нажмите снова.");
      return;
    }
    var clone = table.cloneNode(true);
    var html =
      "<!DOCTYPE html><html><head><meta charset='utf-8'><title>MEBSHOX раскрой</title>" +
      "<style>body{font-family:system-ui,sans-serif;padding:20px;color:#111}" +
      "table{border-collapse:collapse;width:100%;font-size:12px}" +
      "th,td{border:1px solid #ccc;padding:6px 8px;text-align:left}th{background:#f1f5f9}" +
      "h1{font-size:18px}@media print{button{display:none}}</style></head><body>" +
      "<button onclick='window.print()' style='padding:10px 16px;font-weight:700;margin-bottom:12px;cursor:pointer'>Печать / Сохранить PDF</button>" +
      "<h1>" +
      L().title +
      "</h1>" +
      "<p style='color:#555;font-size:13px'>" +
      new Date().toLocaleString() +
      "</p>" +
      clone.outerHTML +
      "<script>setTimeout(function(){window.print()},300)<\\/script></body></html>";
    var stamp = new Date().toISOString().slice(0, 10);
    download("mebshox-raskroy-" + stamp + ".html", html, "text/html;charset=utf-8");
  }

  function copyList() {
    var table = findPartsTable();
    if (!table) {
      alert("Откройте вкладку «Детали / раскрой» (Cutlist), затем нажмите снова.");
      return;
    }
    var text = tableToText(table);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () {
        var btn = document.getElementById("meb-copy-btn");
        if (btn) {
          btn.textContent = L().copied;
          setTimeout(function () {
            btn.textContent = L().copy;
          }, 2000);
        }
      });
    } else {
      downloadTxt();
    }
  }

  function styleBtn(el, bg, color) {
    el.style.cssText =
      "padding:8px 12px;border-radius:12px;border:none;font-size:12px;font-weight:800;cursor:pointer;" +
      "display:inline-flex;align-items:center;gap:6px;background:" +
      bg +
      ";color:" +
      color +
      ";box-shadow:0 4px 14px rgba(0,0,0,.25)";
  }

  function ensureBar() {
    if (document.getElementById("meb-workshop-bar")) return;
    var bar = document.createElement("div");
    bar.id = "meb-workshop-bar";
    bar.style.cssText =
      "position:fixed;right:12px;bottom:12px;z-index:99999;display:flex;flex-wrap:wrap;gap:8px;" +
      "max-width:min(420px,calc(100vw - 24px));padding:10px;border-radius:16px;" +
      "background:rgba(15,23,42,.92);border:1px solid rgba(245,158,11,.45);backdrop-filter:blur(8px)";

    var label = document.createElement("div");
    label.textContent = "📦 " + L().bar;
    label.style.cssText = "width:100%;font-size:11px;color:#fbbf24;font-weight:700;margin-bottom:2px";
    bar.appendChild(label);

    var b1 = document.createElement("button");
    b1.type = "button";
    b1.textContent = L().txt;
    styleBtn(b1, "#f59e0b", "#0f172a");
    b1.onclick = downloadTxt;

    var b2 = document.createElement("button");
    b2.type = "button";
    b2.textContent = L().html;
    styleBtn(b2, "#059669", "#fff");
    b2.onclick = downloadHtml;

    var b3 = document.createElement("button");
    b3.id = "meb-copy-btn";
    b3.type = "button";
    b3.textContent = L().copy;
    styleBtn(b3, "#1e293b", "#e2e8f0");
    b3.style.border = "1px solid #475569";
    b3.onclick = copyList;

    bar.appendChild(b1);
    bar.appendChild(b2);
    bar.appendChild(b3);
    document.body.appendChild(bar);
  }

  function boot() {
    ensureBar();
    // re-ensure after React renders / language switch
    setInterval(ensureBar, 2000);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
